tippy('.routine__warning', {
    allowHTML: true,
    content: '<b style="font-size: 25px;">Наведитесь на время чтобы узнать событие!</b>',
    arrow: true,
    animation: 'shift-away-extreme',
});

tippy('.time__tipi', {
    allowHTML: true,
    arrow: true,
    animation: 'scale',
});

tippy('.first_tipi', {
    content: "Сбор детей",
    // animation: shift-away-extreme,
});